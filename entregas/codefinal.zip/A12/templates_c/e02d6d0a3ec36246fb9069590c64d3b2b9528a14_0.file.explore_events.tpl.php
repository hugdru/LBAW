<?php
/* Smarty version 3.1.29, created on 2016-06-07 02:45:20
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/explore_events.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_575627301ceec6_77987062',
  'file_dependency' => 
  array (
    'e02d6d0a3ec36246fb9069590c64d3b2b9528a14' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/explore_events.tpl',
      1 => 1465263917,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_575627301ceec6_77987062 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Explore Events"), 0, false);
?>

    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/event/explore_events.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->

<h1>Explore Events</h1>
<p>
    <small>Here's some public events that you may like</small>
</p>

<input type="text" class="form-control" placeholder="Search Events" id="search_bar">
<div id="search_results">

</div>

<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html><?php }
}
