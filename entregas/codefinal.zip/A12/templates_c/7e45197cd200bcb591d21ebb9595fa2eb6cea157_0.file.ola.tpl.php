<?php
/* Smarty version 3.1.29, created on 2016-06-07 13:45:49
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/ola.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5756c1fde5d246_75411057',
  'file_dependency' => 
  array (
    '7e45197cd200bcb591d21ebb9595fa2eb6cea157' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/ola.tpl',
      1 => 1465303546,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5756c1fde5d246_75411057 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/event/create_event.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/event/ola.js"><?php echo '</script'; ?>
>

</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->
    <div id="poll">

<form action="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" method="post" enctype="multipart/form-data" onsubmit="return verifyQuestions();">
    <div class="poll-question">
        <h2>Question 1</h2>
        <label>Description <textarea name="description[]" cols="30" rows="4" placeholder="Explain what this question is for" required></textarea></label>
        <br>
        <div>
        </div>
        <label>Option Name <input type="text" name="nameOption"></label>
        <input type="button" name="addOption" value="Add Option">
        <input type="button" name="removeQuestion" value="Remove Question">
    </div>
    <input type="button" name="addQuestion" value="Add Question">
    <div class="poll-submit">
        <input type="hidden" name="csrf" value="<?php echo '<?php ';?>echo $_SESSION['csrf_token']<?php echo '?>';?>">
        <input type="submit" value="Submit" name="Send">
    </div>
</form>
        </div>


<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>
<?php }
}
