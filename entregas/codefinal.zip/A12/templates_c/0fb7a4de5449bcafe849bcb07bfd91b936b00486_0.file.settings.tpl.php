<?php
/* Smarty version 3.1.29, created on 2016-06-07 12:56:49
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/settings.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5756b681adb007_75232865',
  'file_dependency' => 
  array (
    '0fb7a4de5449bcafe849bcb07bfd91b936b00486' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/settings.tpl',
      1 => 1465288526,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5756b681adb007_75232865 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"settings"), 0, false);
?>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/settings.css">
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->

<h1>Settings</h1>

<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
action/users/updateProfile.php" role="form" enctype="multipart/form-data">
<div class="row">
    <div class="col-sm-4">
            <h3>Change Picture</h3>
            <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePhotoVars']->value["idutilizador"];?>
"
                   value="<?php echo $_SESSION['idutilizador'];?>
">

            <div class="form-group">
                <label for="currentPicture">Current Picture</label>
                <img class="img-circle st-profile-img center-block" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_SESSION['foto'];?>
"/>
            </div>

            <div class="form-group">
                <label for="newPicture">New Picture</label>
                <div class="form-group">
                    <input type="file" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePhotoVars']->value["newPhoto"];?>
" id="newPicture">
                </div>
            </div>
    </div>

    <div class="col-sm-4">
            <h3>Profile: Description</h3>
            <div class="form-group">
                <textarea class="form-control" id="dsc" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdateDescriptionVars']->value["newDescription"];?>
"><?php echo $_SESSION['descricao'];?>
</textarea>
            </div>
    </div>

    <div class="col-sm-4">
            <h3>Profile: Region</h3>
            <div class="form-group">
                <input readonly class="form-control" id="dsc" value="<?php echo $_SESSION['pais'];?>
">
            </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-4">
            <h3>Change Email Address</h3>
            <div class="form-group">
                <label for="eml">Email Address</label>
                <input type="email" class="form-control" id="eml" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdateEmailVars']->value["newEmail"];?>
" value="<?php echo $_SESSION['email'];?>
">
            </div>
    </div>

    <div class="col-sm-4">
            <h3>Change Password</h3>
            <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePasswordVars']->value["idutilizador"];?>
"
                   value="<?php echo $_SESSION['idutilizador'];?>
">

            <div class="form-group">
                <label for="originalPassword">Current Password</label>
                <input type="password" class="form-control" id="originalPassword"
                       name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePasswordVars']->value["password"];?>
">
            </div>

            <div class="form-group">
                <label for="newPassword">New Password</label>
                <input type="password" class="form-control" id="newPassword"
                       name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePasswordVars']->value["newPassword"];?>
">
            </div>

            <div class="form-group">
                <label for="newRepeatPassword">New Password (Repeat)</label>
                <input type="password" class="form-control" id="newRepeatPassword"
                       name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePasswordVars']->value["newRepeatPassword"];?>
">
            </div>

            <div class="poll-submit">
                <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionUpdatePasswordVars']->value['csrf'];?>
" value="<?php echo $_SESSION['csrf_token'];?>
">
            </div>
    </div>

    <div class="col-sm-4">
            <h3>Notification Preferences</h3>
            <div class="form-group">
                <label>Send me a Email when</label>
                <div class="checkbox">
                    <label><input type="checkbox" value="">I'm invited to an Event</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="">An event i follow has updates</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="">EventBook has recommended events for me</label>
                </div>
            </div>
    </div>
</div>
    <div id="save">
    <button type="submit" class="btn btn-info" style="margin: 15px 150px;"> <i style="padding-right: 8%;" class="glyphicon glyphicon-ok"></i>Save Profile</button>
    </div>
</form>

<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>
<?php }
}
