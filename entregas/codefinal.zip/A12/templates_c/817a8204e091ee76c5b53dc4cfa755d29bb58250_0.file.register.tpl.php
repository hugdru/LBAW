<?php
/* Smarty version 3.1.29, created on 2016-06-07 11:50:22
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/register.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5756a6ee23f810_46582460',
  'file_dependency' => 
  array (
    '817a8204e091ee76c5b53dc4cfa755d29bb58250' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/register.tpl',
      1 => 1465296620,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5756a6ee23f810_46582460 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"register"), 0, false);
?>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/home.css">
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/users/register.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->

<div class="accountField">
    <h1 style="padding: 0px; margin: 0px; margin-bottom: 20px">Register Account</h1>

    <form role="form" action="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name" style="width: 100%">
                Name
                <a class="pull-right btn btn-default btn-xs" href="<?php echo $_smarty_tpl->tpl_vars['fblink']->value;?>
"><img
                            style="height: 1.5em; vertical-align: top;" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
data/default/facebook.png"> Import
                    data from Facebook</a>
            </label>
            <input name="nome" type="text" class="form-control" id="name" <?php if ($_smarty_tpl->tpl_vars['name']->value) {?>value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
"<?php }?>>
        </div>

        <div id="username_group" class="form-group">
            <label id="username_label" for="username">Username</label>
            <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['username'];?>
" type="text" class="form-control" id="username">
        </div>

        <div class="form-group" id="email_group">
            <label id="email_label" for="email">Email Address</label>
            <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['email'];?>
" type="email" class="form-control" id="email" <?php if ($_smarty_tpl->tpl_vars['email']->value) {?>value="<?php echo $_smarty_tpl->tpl_vars['email']->value;?>
"<?php }?>>
        </div>

        <div class="form-group password_group">
            <label for="password" id="password_label">Password</label>
            <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['password'];?>
" type="password" class="form-control" id="password">
        </div>

        <div class="form-group password_group">
            <label for="passwordRepeat">Password (Repeat)</label>
            <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['passwordRepeat'];?>
" type="password" class="form-control" id="passwordRepeat">
        </div>

        <div class="form-group">
            <label for="file">Profile photo</label>
            <?php if ($_smarty_tpl->tpl_vars['photo']->value) {?>
                <input type="hidden" name="facebook_photo" value="<?php echo $_smarty_tpl->tpl_vars['photo']->value;?>
">
                <img class="img-circle" style="width: 100px; height: 100px" src="<?php echo $_smarty_tpl->tpl_vars['photo']->value;?>
">
            <?php } else { ?>
                <input type="file" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['file'];?>
" placeholder="Optional" id="file">
            <?php }?>
        </div>

        <div class="form-group">
            <label for="country">Your country:</label>
            <select name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['country'];?>
" id="country" class="form-control">
                <?php
$_from = $_smarty_tpl->tpl_vars['countryList']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_country_0_saved_item = isset($_smarty_tpl->tpl_vars['country']) ? $_smarty_tpl->tpl_vars['country'] : false;
$_smarty_tpl->tpl_vars['country'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['country']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['country']->value) {
$_smarty_tpl->tpl_vars['country']->_loop = true;
$__foreach_country_0_saved_local_item = $_smarty_tpl->tpl_vars['country'];
?>
                    <?php if ($_smarty_tpl->tpl_vars['country']->value['idpais'] == 180) {?>
                        <option selected="selected" value='<?php echo $_smarty_tpl->tpl_vars['country']->value["idpais"];?>
'><?php echo $_smarty_tpl->tpl_vars['country']->value["nome"];?>
</option>
                    <?php } else { ?>
                        <option value='<?php echo $_smarty_tpl->tpl_vars['country']->value["idpais"];?>
'><?php echo $_smarty_tpl->tpl_vars['country']->value["nome"];?>
</option>
                    <?php }?>
                <?php
$_smarty_tpl->tpl_vars['country'] = $__foreach_country_0_saved_local_item;
}
if ($__foreach_country_0_saved_item) {
$_smarty_tpl->tpl_vars['country'] = $__foreach_country_0_saved_item;
}
?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary btn-block">Register</button>
    </form>
</div>

<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>


<?php }
}
