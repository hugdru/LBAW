<?php
/* Smarty version 3.1.29, created on 2016-06-05 23:30:55
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/content-bottom.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5754a81fa0a3e3_04654652',
  'file_dependency' => 
  array (
    '2306ee93217627954ccd896a160735c46371dc5e' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/content-bottom.tpl',
      1 => 1465075731,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5754a81fa0a3e3_04654652 ($_smarty_tpl) {
?>
<div class="push"></div>
</div>
<div class="container text-center">
    <small>
        EventBook @ LBAW 2016 - <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/docs/about.php">About</a>
    </small>
</div>
<?php }
}
