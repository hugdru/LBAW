<?php
/* Smarty version 3.1.29, created on 2016-06-07 07:50:12
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/navbar.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57566ea4ef59b9_77152982',
  'file_dependency' => 
  array (
    '9bb0a6a7aee8f9eef3b63c1f6c7e6919773b5fe8' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/navbar.tpl',
      1 => 1465282211,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57566ea4ef59b9_77152982 ($_smarty_tpl) {
?>
<nav id="menu" class="navbar navbar-inverse navbar-fixed-top">
    <?php if (isset($_SESSION['username'])) {?>
    <?php echo '<script'; ?>
 type="text/javascript">
        function logout(){
            var inputCsrf = document.createElement("input");
            inputCsrf.setAttribute("type", "hidden");
            inputCsrf.setAttribute("name", "csrf");
            inputCsrf.setAttribute("value", "<?php echo $_SESSION['csrf_token'];?>
");

            var logoutForm = document.createElement("form");
            logoutForm.action = '<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
action/users/logout.php';
            logoutForm.target = "_self";
            logoutForm.method = "POST";

            var body = document.body;
            
            body.appendChild(logoutForm);
            logoutForm.appendChild(inputCsrf);
            logoutForm.submit();
            return false;
        }
    <?php echo '</script'; ?>
>
    <?php }?>
    
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <?php if (!isset($_SESSION['username'])) {?>
            <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php">EventBook</a>
            <?php } else { ?>
                <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/event/explore_events.php">EventBook</a>
            <?php }?>
        </div>

        <div class="collapse navbar-collapse" id="navigation">
            <ul class="nav navbar-nav">
                <li <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "explore_events") {?> class="active" <?php }?>>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/event/explore_events.php">Explore</a>
                </li>
                <?php if (isset($_SESSION['username'])) {?>
                    <li <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "my_events") {?> class="active" <?php }?>>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/event/my_events.php">My Events</a>
                    </li>
                    <li <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "create_event") {?> class="active" <?php }?> >
                        <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/event/create_event.php">Create</a>
                    </li>
                <?php }?>
                <li <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "top_events") {?> class="active" <?php }?>>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/event/top_events.php">Top</a>
                </li>
            </ul>


            <ul class="nav navbar-nav navbar-right">
                <?php if (!isset($_SESSION['username'])) {?>
                    <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "register") {?>
                        <li class="active">
                            <?php } else { ?>
                        <li><a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/register.php'>Register</a></li>
                    <?php }?>

                    <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == "login") {?>
                        <li class="active">
                            <?php } else { ?>
                        <li><a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/login.php'>Login</a></li>
                    <?php }?>
                <?php } else { ?>
                    <li class='dropdown'>
                        <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true'
                           aria-expanded='false'>
                            <img class='img-circle avatar-nav'
                                 src='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_SESSION['foto'];?>
'><?php echo $_SESSION['username'];?>
<span
                                    class='caret'></span>
                        </a>
                        <ul class='dropdown-menu'>
                            <li><a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/profile.php'>Profile</a></li>
                            <li><a href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/settings.php'>Settings</a></li>
                            <li role='separator' class='divider'></li>
                            <li><a onclick="logout();" id="logout" href="#">Logout</a></li>
                        </ul>
                    </li>
                <?php }?>
            </ul>
        </div>

    </div>
</nav>
<?php if (isset($_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value)) {?>
    <div id="error_messages">
    <?php
$_from = $_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_message_0_saved_item = isset($_smarty_tpl->tpl_vars['message']) ? $_smarty_tpl->tpl_vars['message'] : false;
$_smarty_tpl->tpl_vars['message'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['message']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
$__foreach_message_0_saved_local_item = $_smarty_tpl->tpl_vars['message'];
?>
        <div class="alert alert-danger alert-dismissible" role="alert" id="error_message">
            <button type="button" class="close" onclick="$('#error_message').fadeOut()" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <strong><center><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</center></strong>
        </div>
    <?php
$_smarty_tpl->tpl_vars['message'] = $__foreach_message_0_saved_local_item;
}
if ($__foreach_message_0_saved_item) {
$_smarty_tpl->tpl_vars['message'] = $__foreach_message_0_saved_item;
}
?>
    </div>
<?php }
if (isset($_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value)) {?>
    <div id="success_messages">
        <?php
$_from = $_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_message_1_saved_item = isset($_smarty_tpl->tpl_vars['message']) ? $_smarty_tpl->tpl_vars['message'] : false;
$_smarty_tpl->tpl_vars['message'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['message']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
$__foreach_message_1_saved_local_item = $_smarty_tpl->tpl_vars['message'];
?>
            <div class="alert alert-success alert-dismissible" role="alert" id="success_message">
                <button type="button" class="close" onclick="$('#success_message').fadeOut()" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <strong><center><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</strong></center>
            </div>
        <?php
$_smarty_tpl->tpl_vars['message'] = $__foreach_message_1_saved_local_item;
}
if ($__foreach_message_1_saved_item) {
$_smarty_tpl->tpl_vars['message'] = $__foreach_message_1_saved_item;
}
?>
    </div>
<?php }?>


<?php }
}
