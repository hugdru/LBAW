<?php
/* Smarty version 3.1.29, created on 2016-06-05 23:30:55
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/content-top.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5754a81fa06933_90125916',
  'file_dependency' => 
  array (
    'e2bbdc6f4872ae36cf5c7d0efd289d9ad56a85ec' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/common/content-top.tpl',
      1 => 1464099253,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5754a81fa06933_90125916 ($_smarty_tpl) {
?>
<div class="container wrapper" id="content">

<?php }
}
