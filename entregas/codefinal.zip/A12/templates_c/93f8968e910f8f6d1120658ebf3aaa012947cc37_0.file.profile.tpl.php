<?php
/* Smarty version 3.1.29, created on 2016-06-07 12:56:46
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/profile.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5756b67e26ef58_79911522',
  'file_dependency' => 
  array (
    '93f8968e910f8f6d1120658ebf3aaa012947cc37' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/users/profile.tpl',
      1 => 1465288526,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5756b67e26ef58_79911522 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"profile"), 0, false);
?>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/home.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/profile.css">
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->
<div class="row">
    <div id="profile-imgbox" class="col-md-4">
        <img class="img-responsive img-circle" style="min-width: 100%" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['user']->value["foto"];?>
"/>
    </div>
    <?php if ($_smarty_tpl->tpl_vars['user']->value['idutilizador'] == $_SESSION['idutilizador']) {?>
    <div id="edit">
        <a type="button" role="button" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/settings.php" class="btn btn-info" style="margin: 15px 150px;"> <i style="padding-right: 8%;" class="glyphicon glyphicon-pencil"></i>Edit Profile</a>
    </div>
    <?php }?>
    <div id="profile-detailbox" class="col-md-8">
        <h2><?php echo $_smarty_tpl->tpl_vars['user']->value["nome"];?>
</h2>

        <label for="description"> <i class="glyphicon glyphicon-pencil"></i> Description</label>
        <p id="description"><?php echo $_smarty_tpl->tpl_vars['user']->value["descricao"];?>
</p>

        <label for="region"> <i class="glyphicon glyphicon-map-marker"></i> Country</label>
        <p id="region"><?php echo $_smarty_tpl->tpl_vars['user']->value["pais"];?>
</p>

        <label for="since"> <i class="glyphicon glyphicon-time"></i> Member Since</label>
        <p id="since"><?php echo $_smarty_tpl->tpl_vars['user']->value["datacriacao"];?>
</p>

        <label for="email"> <i class="glyphicon glyphicon-envelope"></i> Email</label>
        <p id="email"><?php echo $_smarty_tpl->tpl_vars['user']->value["email"];?>
</p>

        <label for="stats"> <i class="glyphicon glyphicon-stats"></i> Statistics</label>
        <p id="stats">Events: Joined <?php echo $_smarty_tpl->tpl_vars['user']->value["joins"];?>
, Hosted <?php echo $_smarty_tpl->tpl_vars['user']->value["hosts"];?>
</p>
    </div>
</div>
        
<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>
<?php }
}
