<?php
/* Smarty version 3.1.29, created on 2016-06-07 07:44:47
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/top_events.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57566d600081a3_40561345',
  'file_dependency' => 
  array (
    '9fa0e54c379de355d72f920894d5fe3e01366467' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/top_events.tpl',
      1 => 1465281782,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_57566d600081a3_40561345 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Top Events"), 0, false);
?>

    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/event/top_events.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->

<h1>Top Events</h1>
<p>
    <small>Here are some events that you might like</small>
</p>

<div id="search_results">
</div>

<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html><?php }
}
