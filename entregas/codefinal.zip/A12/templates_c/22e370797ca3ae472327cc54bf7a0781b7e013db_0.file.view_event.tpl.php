<?php
/* Smarty version 3.1.29, created on 2016-06-07 12:55:31
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/view_event.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5756b633917416_59163932',
  'file_dependency' => 
  array (
    '22e370797ca3ae472327cc54bf7a0781b7e013db' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/view_event.tpl',
      1 => 1465300505,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5756b633917416_59163932 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/lib/smarty/plugins/modifier.date_format.php';
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/home.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/event.css">
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->
<div class="row">
    <div id="event-imgbox" class="col-md-4">
        <h2><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['event']->value['titulo'], ENT_QUOTES, 'UTF-8', true);?>
</h2>
        <img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['event']->value['capa'];?>
" class="img-thumbnail" alt="Capa" width="450" height="400">
    </div>
    <?php if ($_smarty_tpl->tpl_vars['is_host']->value) {?>
        <!-- Button trigger modal -->
        <div id="cancel-event">
            <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#myModal" style="margin: 15px 150px;"> <i style="padding-right: 8%;" class="glyphicon glyphicon-remove"></i>
                Cancel Event
            </button>
        </div>
        <div id="edit-event">
            <a type="button" role="button" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/edit_event.php'" class="btn btn-info" style="margin: 15px 150px;"> <i style="padding-right: 8%;" class="glyphicon glyphicon-pencil"></i>Edit Event</a>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Do you really want to cancel the event?</h4>
                    </div>
                    <div class="modal-footer">
                        <button id="close" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
action/event/cancel_event.php" role="form" enctype="multipart/form-data">
                            <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionCancelEventVars']->value["idEvent"];?>
"
                                   value="<?php echo $_smarty_tpl->tpl_vars['idevent']->value;?>
">
                            <div id="cancel-event2">
                                <button type="submit" class="btn btn-primary" style="margin: 15px 150px;"> <i style="padding-right: 8%;" class="glyphicon glyphicon-remove"></i>Yes i want</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php }?>
    <div id="event-detailbox" class="col-md-8">
        <h2>Details</h2>
        <div class="row">
            <div class="col-sm-6">
                <label for="timeanddate"> <i class="glyphicon glyphicon-time"></i> Time & Date</label>
                <p id="timeanddate"><?php echo smarty_modifier_date_format(htmlspecialchars($_smarty_tpl->tpl_vars['event']->value['datainicio'], ENT_QUOTES, 'UTF-8', true),"%H:%M, %A, %B %e, %Y");?>
</p>
            </div>
            <div class="col-sm-6">
                <label for="location"><i class="glyphicon glyphicon-map-marker"></i> Location</label>
                <p id="location"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['event']->value['localizacao'], ENT_QUOTES, 'UTF-8', true);?>
 <a href="#">(View in Map)</a></p>
            </div>
        </div>
        <label for="hosts"> <i class="glyphicon glyphicon-user"></i> Host(s)</label>
        <p id="hosts"><?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? count($_smarty_tpl->tpl_vars['hosts']->value)-1+1 - (0) : 0-(count($_smarty_tpl->tpl_vars['hosts']->value)-1)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration == 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration == $_smarty_tpl->tpl_vars['i']->total;
echo htmlspecialchars($_smarty_tpl->tpl_vars['hosts']->value[$_smarty_tpl->tpl_vars['i']->value]["nome"], ENT_QUOTES, 'UTF-8', true);
if ($_smarty_tpl->tpl_vars['i']->value != count($_smarty_tpl->tpl_vars['hosts']->value)-1) {?>, <?php }
}
}
?>
</p>
        <label for="description"><i class="glyphicon glyphicon-comment"></i> Description</label>
        <p id="description">
            <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['event']->value['descricao'], ENT_QUOTES, 'UTF-8', true);?>

        </p>
        <div class="row">
            <div class="col-sm-6">
                <label for="attenders"><i class="glyphicon glyphicon-user"></i> Participants</label>
                <p id="attenders"><?php echo $_smarty_tpl->tpl_vars['number_part']->value;?>
 People have joined this event <a href="#">(List)</a></p>
            </div>
            <div class="col-sm-6">
                <label for="share"><i class="glyphicon glyphicon-link"></i> Share</label>
                <p id="share"><a href="#">Facebook</a>, <a href="#">Email</a></p>
            </div>
        </div>
            <label for="visibility">
                <?php if ($_smarty_tpl->tpl_vars['event']->value['publico']) {?>
                <i class="glyphicon glyphicon-eye-open"></i> Visibility</label>
                <p>This is a public event. Everyone can access it.</p>
                <?php } else { ?>
                <i class="glyphicon glyphicon-eye-close"></i> Visibility</label>
                <p>This is a private event. Only invited users can access it.</p>
                <?php }?>
    </div>
</div>
<br><br>
<div class="row">
<?php if ($_smarty_tpl->tpl_vars['is_participant']->value) {
} elseif (isset($_SESSION['username'])) {?>
    <label for="intention">Are you going to this event?</label>
    <div class="going">
        <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
action/event/setIntention.php" role="form" enctype="multipart/form-data">
            <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionIntentionVar']->value["idEvent"];?>
" value="<?php echo $_smarty_tpl->tpl_vars['event']->value['idevento'];?>
">
            <button type="submit" class="btn btn-success glyphicon glyphicon-ok"> YES!</button>
        </form>
    </div>
<?php } else { ?>
    <label for="intention">Register to join this event!</label>
    <div id="edit-event">
        <a type="button" role="button" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/users/register.php'" class="btn btn-primary" >Register</a>
    </div>
<?php }?>
</div>
<h2><i class="glyphicon glyphicon-comment"></i> Comments</h2>
<table>
    <?php
$_from = $_smarty_tpl->tpl_vars['comments']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_comm_0_saved_item = isset($_smarty_tpl->tpl_vars['comm']) ? $_smarty_tpl->tpl_vars['comm'] : false;
$_smarty_tpl->tpl_vars['comm'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['comm']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['comm']->value) {
$_smarty_tpl->tpl_vars['comm']->_loop = true;
$__foreach_comm_0_saved_local_item = $_smarty_tpl->tpl_vars['comm'];
?>
    <tr>
        <td class="hidden-xs text-center">
            <div class="comment-holder">
                <img class='img-circle avatar' src='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;
echo $_smarty_tpl->tpl_vars['comm']->value["foto"];?>
' alt='avatar'>
                <p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['comm']->value["username"], ENT_QUOTES, 'UTF-8', true);?>
</p>
            </div>
        </td>
        <td>
            <div class="comment">
                <strong class="visible-xs"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['comm']->value["username"], ENT_QUOTES, 'UTF-8', true);?>
</strong>
                <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['comm']->value["texto"], ENT_QUOTES, 'UTF-8', true);?>

            </div>
        </td>
    </tr>
    <?php
$_smarty_tpl->tpl_vars['comm'] = $__foreach_comm_0_saved_local_item;
}
if ($__foreach_comm_0_saved_item) {
$_smarty_tpl->tpl_vars['comm'] = $__foreach_comm_0_saved_item;
}
?>

    <?php if (isset($_SESSION['username'])) {?>
    <!-- POST COMMENT AREA -->
    <tr>
        <td colspan="2" class="text-right" style="width: 1000px">
            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['actionComment']->value;?>
" role="form" enctype="multipart/form-data">
                <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionCommentVars']->value["idEvent"];?>
"
                       value="<?php echo $_smarty_tpl->tpl_vars['event']->value['idevento'];?>
">
                <p><textarea style="min-height: 100px;" class="form-control" name="<?php echo $_smarty_tpl->tpl_vars['actionCommentVars']->value["newComment"];?>
" placeholder="New Comment..."></textarea></p>
                <p><button type="submit" class="btn btn-primary">Post</button></p>
            </form>
        </td>
    </tr>
    <?php }?>

</table>
<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>
<?php }
}
