<?php
/* Smarty version 3.1.29, created on 2016-06-05 23:44:39
  from "/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/create_event.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5754ab579ea239_32292698',
  'file_dependency' => 
  array (
    '839e656a430b4494b58d036c3aacd65b1361677d' => 
    array (
      0 => '/home/hugdru/data/projetos/lbaw1522/Artefatos/A12/templates/event/create_event.tpl',
      1 => 1465155964,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/content-top.tpl' => 1,
    'file:common/content-bottom.tpl' => 1,
  ),
),false)) {
function content_5754ab579ea239_32292698 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
js/event/create_event.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('currentPage'=>((string)$_smarty_tpl->tpl_vars['currentPage']->value)), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!-- Content Start -->

<h1>Create Event</h1>

<form role="form" id="create_event_form" action="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title">Event Title</label>
        <input type="text" class="form-control" id="title" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['title'];?>
" required>
    </div>

    <div class="form-group">
        <label>Cover Picture</label>
        <input type="file" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['file'];?>
" class="form-control-static">
    </div>

    <div class="form-group">
        <label>Event Privacy</label>
        <div class="radio">
            <label>
                <input type="radio" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['public'];?>
" value="true" checked="checked">
                Public<br>
                <small>Viewable in the explore page, and joinable by anyone.</small>
            </label>
        </div>
        <div class="radio">
            <label>
                <input type="radio" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['public'];?>
" value="false">
                Private<br>
                <small>Users cannot view or join the event unless invited by a host.</small>
            </label>
        </div>
    </div>

    <div class="form-group">
        <label>Event Date</label>
        <div style="overflow:hidden;">
            <div class="form-group">
                <div class="row">
                    <div class="col-md-12">
                        <div id="eventDateTimePicker"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label id="location_label" for="duration">Duration</label>
        <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['duration'];?>
" type="number" class="form-control" id="duration" required> minutes
    </div>

    <div class="form-group">
        <label for="description">Description</label>
        <textarea style="min-height: 200px; resize: none;" class="form-control" id="description" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['description'];?>
" required></textarea>
    </div>

    <div class="form-group">
        <label id="location_label" for="location">Location</label>
        <input name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['location'];?>
" type="text" class="form-control" id="location" required>
    </div>

    <div class="poll-submit">
        <input type="hidden" name="<?php echo $_smarty_tpl->tpl_vars['actionVars']->value['csrf'];?>
" value="<?php echo $_SESSION['csrf_token'];?>
">
        <button type="submit" class="btn btn-primary">Create Event</button>
    </div>
</form>

<!-- Content Finish -->
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:common/content-bottom.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

</body>
</html>
<?php }
}
