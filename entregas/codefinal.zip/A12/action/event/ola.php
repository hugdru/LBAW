<?php

var_dump($_POST);
exit();


if (!isset($_POST['option'])) {
    exit();
}

// Malicious user could send "array" with different indexes
$i = 0;
$descriptions = [];
foreach ($_POST['description'] as $desc) {
    if ($desc === '') {
        header('location: pollCreate.php?err=invalidDescription');
        exit();
    }
    $descriptions[$i] = $desc;
    ++$i;
}

// Same
$options = [];
$i = 0;
foreach ($_POST['option'] as $option) {

    if (count($option) < 2) {
        header('Location: pollCreate.php?err=MissingOptions');
        exit();
    }

    $t = 0;
    foreach ($option as $radio) {
        if ($radio === '') {
            header('location: pollCreate.php?err=invalidRadio');
            exit();
        }
        $options[$i][$t] = $radio;
        ++$t;
    }
    ++$i;
}

// Insert the Questions in the database
$stmt = $dbh->prepare(
    'INSERT INTO Question (options, result, description, idPoll)
    VALUES (:option, :result, :description, :idPoll)'
);
foreach ($options as $key =>$option) {
    $jsonOption = json_encode($option);
    $jsonResult = json_encode(array_fill(0, count($option), 0));
    $stmt->bindParam(':option', $jsonOption);
    $stmt->bindValue(':result', $jsonResult);
    $stmt->bindParam(':description', $descriptions[$key]);
    $stmt->bindParam(':idPoll', $pollId);
    if (!$stmt->execute()) {
        $dbh->rollBack();
        header('Location: pollCreate.php?err=Insert');
        exit();
    }
}


?>