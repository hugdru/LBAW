<?php
include_once('../../config/init.php');
include_once($BASE_DIR . 'database/users.php');
include_once($BASE_DIR . 'functions/users.php');

redirectIfNotLoggedIn($BASE_URL . "pages/users/login.php");

$smarty->assign('currentPage', "ola");
$smarty->assign('action', $BASE_URL . "action/event/ola.php");
$smarty->display('event/ola.tpl');
?>
