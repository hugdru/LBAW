<?php
include_once('../../config/init.php');

$smarty->assign('currentPage', "about");
$smarty->display('docs/about.tpl');
?>



